/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import service.LoginService;
import sustav.Utils;
import sustav.model.Policajac;
import sustav.model.Osoba;

/**
 *
 * @author HP
 */
public class IzbornikController implements Initializable {
    
    @FXML
    Label policajac;
    
    @FXML
    ImageView policajac_img;
    ImageView osoba_img;
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    Policajac prijavljeni = LoginService.logiraniPolicajac();
        policajac.setText("Prijavljeni ste kao " + prijavljeni.getKorisnicko_ime());
    } 
    
     @FXML
    private void proslijedinapolicajce(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Policajac");
    };
    
     @FXML
    private void proslijedinaosobe(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Osoba");
    };
    
     @FXML
    private void odjavi(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "LoginView");
    };
    
       @FXML
    private void proslijedinaoaplikaciji(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Oaplikaciji");
    };
    
    
    
}
