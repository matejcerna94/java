/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;
import sustav.Utils;

/**
 *
 * @author HP
 */
public class OaplikacijiController {
    
    
    @FXML
    private void povrataknaizbornik(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Izbornik");
    };
}
