/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav.controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import service.OsobaService;
import sustav.Utils;
import sustav.model.Osoba;


/**
 *
 * @author HP
 */
public class OsobaController implements Initializable {
    
     
    
    
    @FXML
    TextField ime;
    
    @FXML
    TextField prezime;
    
    @FXML
    TextField mjesto_rodenja;
    
    @FXML
    TextField datum_rodenja;
    
    @FXML
    TextField adresa;
    
    @FXML
    TextField spol;
    
    @FXML
    TextField broj_osobne;
    
    @FXML
    TextField oib;
    
    @FXML
    TextField telefon;
    
    @FXML
    TextField zupanija;
    
    @FXML
    TextField grad;
    
    @FXML
    ImageView slika;
    
    FileChooser filechooser = new FileChooser();
    
    
    @FXML
    TextField pretraga;
    
    
    
    
    
    
    
    
    
    @FXML
    TableView table;
    
    @FXML
    TableColumn tableId;
    
    @FXML
    TableColumn tableIme;    
    
    @FXML
    TableColumn tablePrezime;
    
    @FXML
    TableColumn tableMjesto_rodenja;
    
    @FXML
    TableColumn tableDatum_rodenja;
    
    @FXML
    TableColumn tableAdresa;
    
    @FXML
    TableColumn tableSpol;
    
    @FXML
    TableColumn tableBroj_osobne;
    
    @FXML
    TableColumn tableOib;
    
    @FXML
    TableColumn tableTelefon;
    
    @FXML
    TableColumn tableZupanija;
    
    @FXML
    TableColumn tableGrad;
    
    Osoba odabranaOsoba;
    byte[] slika_osobe;
    
   
    
    
    
    
    @FXML
    public void dodajOsobu (ActionEvent evt) {
        String oIme = this.ime.getText();
        String oPrezime = this.prezime.getText();
        String oMjesto_rodenja = this.mjesto_rodenja.getText();
        String oDatum_rodenja = this.datum_rodenja.getText();
        String oAdresa = this.adresa.getText();
        String oSpol = this.spol.getText();
        String oBroj_osobne = this.broj_osobne.getText();
        String oOib = this.oib.getText();
        String oTelefon = this.telefon.getText();
        String oZupanija = this.zupanija.getText();
        String oGrad = this.grad.getText();
        byte[] oSlika;
        if(file!=null){
        oSlika=slika_osobe;
        }else{
            
            oSlika=img;
        }
        
        
        
        
        
        
        
        
    
        
        
        if(oIme.equals("") || oPrezime.equals("") || oMjesto_rodenja.equals("")
                || oDatum_rodenja.equals("") || oAdresa.equals("") || oSpol.equals("")
                || oSpol.equals("") || oBroj_osobne.equals("") || oOib.equals("") || oTelefon.equals("")
                || oZupanija.equals("") || oGrad.equals("") || oSlika==null){
            
            JOptionPane.showMessageDialog(null, "Jedno ili više polja je ostalo prazno, molimo popunite sva polja!");
            
        }else{
            
            if(odabranaOsoba==null){
        
        
        Osoba o = new Osoba (0, oIme, oPrezime, oMjesto_rodenja, oDatum_rodenja, oAdresa, oSpol, oBroj_osobne, oOib, oTelefon, oZupanija, oGrad, oSlika);
        OsobaService.osobaService.spasi(o);
        this.ime.setText("");
        this.prezime.setText("");
        this.mjesto_rodenja.setText("");
        this.datum_rodenja.setText("");
        this.adresa.setText("");
        this.spol.setText("");
        this.broj_osobne.setText("");
        this.oib.setText("");
        this.telefon.setText("");
        this.zupanija.setText("");
        this.grad.setText("");
        slika.setImage(null);
        
        
        file=null;// ponistavamo zadnju odabranu sliku za dodavanje korisnika
        
        
        this.popuniOsobe();
        this.odabranaOsoba=null;// ovdje smo onemogucili unos dvije iste osobe
        }else{
                
                 JOptionPane.showMessageDialog(null, "Odabrana osoba već postoji!");
                 
            }
        }
    }
    
    
    
    public void urediOsobu (ActionEvent evt) {
        
        if(odabranaOsoba==null){
             JOptionPane.showMessageDialog(null, "Niste odabrali osobu!");
        }
        
        String oIme = this.ime.getText();
        String oPrezime = this.prezime.getText();
        String oMjesto_rodenja = this.mjesto_rodenja.getText();
        String oDatum_rodenja = this.datum_rodenja.getText();
        String oAdresa = this.adresa.getText();
        String oSpol = this.spol.getText();
        String oBroj_osobne = this.broj_osobne.getText();
        String oOib = this.oib.getText();
        String oTelefon = this.telefon.getText();
        String oZupanija = this.zupanija.getText();
        String oGrad = this.grad.getText();
        byte[] oSlika=slika_osobe;
        
        if(odabranaOsoba !=null){
            
            this.odabranaOsoba.setIme(oIme);
            this.odabranaOsoba.setPrezime(oPrezime);
            this.odabranaOsoba.setMjesto_rodenja(oMjesto_rodenja);
            this.odabranaOsoba.setDatum_rodenja(oDatum_rodenja);
            this.odabranaOsoba.setAdresa(oAdresa);
            this.odabranaOsoba.setSpol(oSpol);
            this.odabranaOsoba.setBroj_osobne(oBroj_osobne);
            this.odabranaOsoba.setOib(oOib);
            this.odabranaOsoba.setTelefon(oTelefon);
            this.odabranaOsoba.setZupanija(oZupanija);
            this.odabranaOsoba.setGrad(oGrad);
            
            if(file!=null){
            this.odabranaOsoba.setSlika(slika_osobe);
            }
            
            else{
                this.odabranaOsoba.setSlika(img);
            }
            
            
            
            
            OsobaService.osobaService.uredi(this.odabranaOsoba);
            this.odabranaOsoba=null;
            
        }
        
        this.ime.setText("");
        this.prezime.setText("");
        this.mjesto_rodenja.setText("");
        this.datum_rodenja.setText("");
        this.adresa.setText("");
        this.spol.setText("");
        this.broj_osobne.setText("");
        this.oib.setText("");
        this.telefon.setText("");
        this.zupanija.setText("");
        this.grad.setText("");
        slika.setImage(null);
        this.popuniOsobe();
    }
    
    
     public void brisiOsobu (ActionEvent evt) {
         
            if(this.odabranaOsoba==null){
             JOptionPane.showMessageDialog(null, "Niste odabrali osobu!");
        }
        String oIme = this.ime.getText();
        String oPrezime = this.prezime.getText();
        String oMjesto_rodenja = this.mjesto_rodenja.getText();
        String oDatum_rodenja = this.datum_rodenja.getText();
        String oAdresa = this.adresa.getText();
        String oSpol = this.spol.getText();
        String oBroj_osobne = this.broj_osobne.getText();
        String oOib = this.oib.getText();
        String oTelefon = this.telefon.getText();
        String oZupanija = this.zupanija.getText();
        String oGrad = this.grad.getText();
        byte[] oSlika=slika_osobe;
        
        
        if(this.odabranaOsoba !=null){
            
            this.odabranaOsoba.setIme(oIme);
            this.odabranaOsoba.setPrezime(oPrezime);
            this.odabranaOsoba.setMjesto_rodenja(oMjesto_rodenja);
            this.odabranaOsoba.setDatum_rodenja(oDatum_rodenja);
            this.odabranaOsoba.setAdresa(oAdresa);
            this.odabranaOsoba.setSpol(oSpol);
            this.odabranaOsoba.setBroj_osobne(oBroj_osobne);
            this.odabranaOsoba.setOib(oOib);
            this.odabranaOsoba.setTelefon(oTelefon);
            this.odabranaOsoba.setZupanija(oZupanija);
            this.odabranaOsoba.setGrad(oGrad);
            this.odabranaOsoba.setSlika(slika_osobe);
            
            
            OsobaService.osobaService.brisi(this.odabranaOsoba);
            this.odabranaOsoba=null;
            
         
            
        }
        
        this.ime.setText("");
        this.prezime.setText("");
        this.mjesto_rodenja.setText("");
        this.datum_rodenja.setText("");
        this.adresa.setText("");
        this.spol.setText("");
        this.broj_osobne.setText("");
        this.oib.setText("");
        this.telefon.setText("");
        this.zupanija.setText("");
        this.grad.setText("");
        slika.setImage(null);
        
        this.popuniOsobe();
    }
     
     @FXML
     public void pretrazeneOsobe (KeyEvent evt) {
        ObservableList <Osoba> osobe = OsobaService.osobaService.traziIzBaze(pretraga.getText());
        
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableIme.setCellValueFactory(new PropertyValueFactory<>("ime"));
        tablePrezime.setCellValueFactory(new PropertyValueFactory<>("prezime"));
        tableMjesto_rodenja.setCellValueFactory(new PropertyValueFactory<>("mjesto_rodenja"));
        tableDatum_rodenja.setCellValueFactory(new PropertyValueFactory<>("datum_rodenja"));
        tableAdresa.setCellValueFactory(new PropertyValueFactory<>("adresa"));
        tableSpol.setCellValueFactory(new PropertyValueFactory<>("spol"));
        tableBroj_osobne.setCellValueFactory(new PropertyValueFactory<>("broj_osobne"));
        tableOib.setCellValueFactory(new PropertyValueFactory<>("oib"));
        tableTelefon.setCellValueFactory(new PropertyValueFactory<>("telefon"));
        tableZupanija.setCellValueFactory(new PropertyValueFactory<>("zupanija"));
        tableGrad.setCellValueFactory(new PropertyValueFactory<>("grad"));
        
        
        table.setItems(osobe);
    }
    
     public void popuniOsobe () {
        ObservableList <Osoba> osobe = OsobaService.osobaService.sveIzBaze();
        
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableIme.setCellValueFactory(new PropertyValueFactory<>("ime"));
        tablePrezime.setCellValueFactory(new PropertyValueFactory<>("prezime"));
        tableMjesto_rodenja.setCellValueFactory(new PropertyValueFactory<>("mjesto_rodenja"));
        tableDatum_rodenja.setCellValueFactory(new PropertyValueFactory<>("datum_rodenja"));
        tableAdresa.setCellValueFactory(new PropertyValueFactory<>("adresa"));
        tableSpol.setCellValueFactory(new PropertyValueFactory<>("spol"));
        tableBroj_osobne.setCellValueFactory(new PropertyValueFactory<>("broj_osobne"));
        tableOib.setCellValueFactory(new PropertyValueFactory<>("oib"));
        tableTelefon.setCellValueFactory(new PropertyValueFactory<>("telefon"));
        tableZupanija.setCellValueFactory(new PropertyValueFactory<>("zupanija"));
        tableGrad.setCellValueFactory(new PropertyValueFactory<>("grad"));
        
        
        table.setItems(osobe);
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
        this.popuniOsobe();
    }   
    
    
    @FXML
    private void povrataknaizbornik(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Izbornik");
    };
    
    @FXML
    byte[] img;
    public void postaviOsobu(MouseEvent evt) throws IOException{
        
        /*
    
            int index=this.table.getSelectionModel().getSelectedIndex();
            
            Korisnik k=this.table.getItems().get(index);
    */
        
        Osoba o=(Osoba) this.table.getSelectionModel().getSelectedItem();
        
        this.odabranaOsoba=(Osoba) this.table.getSelectionModel().getSelectedItem();
        this.ime.setText(this.odabranaOsoba.getIme());
        this.prezime.setText(this.odabranaOsoba.getPrezime());
        this.mjesto_rodenja.setText(this.odabranaOsoba.getMjesto_rodenja());
        this.datum_rodenja.setText(this.odabranaOsoba.getDatum_rodenja());
        this.adresa.setText(this.odabranaOsoba.getAdresa());
        this.spol.setText(this.odabranaOsoba.getSpol());
        this.broj_osobne.setText(this.odabranaOsoba.getBroj_osobne());
        this.oib.setText(this.odabranaOsoba.getOib());
        this.telefon.setText(this.odabranaOsoba.getTelefon());
        this.zupanija.setText(this.odabranaOsoba.getZupanija());
        this.grad.setText(this.odabranaOsoba.getGrad());
        
        img = this.odabranaOsoba.getSlika();
        ByteArrayInputStream in = new ByteArrayInputStream(img);
        BufferedImage read = ImageIO.read(in);
        slika.setImage(SwingFXUtils.toFXImage(read, null));
        
       
        
        }
    
    public void ocistiPolja(ActionEvent evt){
        this.ime.setText("");
        this.prezime.setText("");
        this.mjesto_rodenja.setText("");
        this.datum_rodenja.setText("");
        this.adresa.setText("");
        this.spol.setText("");
        this.broj_osobne.setText("");
        this.oib.setText("");
        this.telefon.setText("");
        this.zupanija.setText("");
        this.grad.setText("");
        slika.setImage(null);        
        img=null; //ponistavamo sliku
        
        
        
        odabranaOsoba=null;
        
        
        
    }
    
    @FXML
    File file;
    public void dodajSliku(ActionEvent evt) {
        FileChooser fileChooser = new FileChooser();
        
        FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.JPG");
        FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.PNG");
        fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterPNG);
        //Show open file dialog
        file = fileChooser.showOpenDialog(null);
        
        //File f = fileChooser.getSelectedFile();
        //filename = f.getAbsolutePath();
        try {
            BufferedImage bufferedImage = ImageIO.read(file);
            WritableImage image = SwingFXUtils.toFXImage(bufferedImage, null);
            slika.setImage(image);
            
            
            try (ByteArrayOutputStream out = new ByteArrayOutputStream(262144)) {
                ImageIO.write(bufferedImage, "jpg", out);
                ImageIO.write(bufferedImage, "png", out);
                out.flush();
                slika_osobe = out.toByteArray();
        }} catch (IOException ex) {
          
        }
    }
    
    
    
}
