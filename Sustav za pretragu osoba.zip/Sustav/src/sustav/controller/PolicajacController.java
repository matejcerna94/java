/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav.controller;

import javafx.scene.input.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import service.LoginService;
import service.PolicajacService;
import sustav.Utils;
import sustav.model.Policajac;


/**
 *
 * @author HP
 */
public class PolicajacController implements Initializable {
    
       /**
     * Initializes the controller class.
     */
    
    ObservableList<Policajac> data=FXCollections.observableArrayList();
    FilteredList<Policajac> filteredData=new FilteredList<>(data,e->true);
    
    @FXML
    Label policajac;
    
    
    
    
    
    @FXML
    TextField korisnicko_ime;
    
    
    @FXML
    PasswordField lozinka;
    
    
    @FXML
    TableView table;
    
    @FXML
    TableColumn tableId;
    
    @FXML
    TableColumn tableKorisnicko_ime;
    
    
    @FXML
    TableColumn tableLozinka;
    
    Policajac odabraniPolicajac;
    
    
    
   
    
   
    
    
    @FXML
    public void dodajPolicajca (ActionEvent evt) {
        String pKorisnicko_ime = this.korisnicko_ime.getText();
        String pLozinka = this.lozinka.getText();
        
        if(pKorisnicko_ime.equals("") || pLozinka.equals("")){
            
            JOptionPane.showMessageDialog(null, "Jedno ili više polja je ostalo prazno, molimo popunite sva polja!");
        }else{
        
        Policajac p = new Policajac (0, pKorisnicko_ime, pLozinka);
        PolicajacService.policajacService.spasi(p);
        
        
        this.korisnicko_ime.setText("");
        this.lozinka.setText("");
        this.popuniPolicajce();
        }
    }
    
    public void urediPolicajca (ActionEvent evt) {
        
        if(odabraniPolicajac==null){
            JOptionPane.showMessageDialog(null, "Niste odabrali policajca!");
            
        }
        
        String pKorisnicko_ime = this.korisnicko_ime.getText();
        String pLozinka = this.lozinka.getText();
        
        if(this.odabraniPolicajac !=null){
            
            this.odabraniPolicajac.setKorisnicko_ime(pKorisnicko_ime);
            this.odabraniPolicajac.setLozinka(pLozinka);
            
            
            PolicajacService.policajacService.uredi(this.odabraniPolicajac);
            this.odabraniPolicajac=null;
            
        }
        
        this.korisnicko_ime.setText("");
        this.lozinka.setText("");
        this.popuniPolicajce();
    }
    
    public void brisiPolicajca (ActionEvent evt) {
        
        if(odabraniPolicajac==null){            
            JOptionPane.showMessageDialog(null, "Niste odabrali policajca!");
        }
        
        String pKorisnicko_ime = this.korisnicko_ime.getText();
        String pLozinka = this.lozinka.getText();
        
        if(this.odabraniPolicajac !=null){
            
            this.odabraniPolicajac.setKorisnicko_ime(pKorisnicko_ime);
            this.odabraniPolicajac.setLozinka(pLozinka);
            
            
            PolicajacService.policajacService.brisi(this.odabraniPolicajac);
            this.odabraniPolicajac=null;
            
        }
        
        this.korisnicko_ime.setText("");
        this.lozinka.setText("");
        this.popuniPolicajce();
    }
    
     public void popuniPolicajce () {
        ObservableList <Policajac> policajci = PolicajacService.policajacService.sveIzBaze();
        
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableKorisnicko_ime.setCellValueFactory(new PropertyValueFactory<>("korisnicko_ime"));
        tableLozinka.setCellValueFactory(new PropertyValueFactory<>("lozinka"));
        
        table.setItems(policajci);
        
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Policajac prijavljeni = LoginService.logiraniPolicajac();
        policajac.setText("Prijavljeni ste kao " + prijavljeni.getKorisnicko_ime());
        this.popuniPolicajce();
    }   
    
    
    @FXML
    private void povrataknaizbornik(ActionEvent event){
             Node source = (Node) event.getSource();
                Stage stage = (Stage)source.getScene().getWindow();
                Utils.prikazi(stage, "Izbornik");
    };
    
    @FXML
    public void postaviKorisnika(MouseEvent evt){
        
        /*
    
            int index=this.table.getSelectionModel().getSelectedIndex();
            
            Korisnik k=this.table.getItems().get(index);
    */
        
        Policajac p=(Policajac) this.table.getSelectionModel().getSelectedItem();
        
        this.odabraniPolicajac=(Policajac) this.table.getSelectionModel().getSelectedItem();
        this.korisnicko_ime.setText(this.odabraniPolicajac.getKorisnicko_ime());
        this.lozinka.setText(this.odabraniPolicajac.getLozinka());
        
        }
    
    public void ocistiPolja(ActionEvent evt){
        this.korisnicko_ime.setText("");
        this.lozinka.setText("");
        
        odabraniPolicajac=null;
        
        
        
        
    }
    
    
  
    
    
    
   
    
   
    
}
