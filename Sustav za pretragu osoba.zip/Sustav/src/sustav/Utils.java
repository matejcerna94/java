/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Utils {
     public static void prikazi (Stage window, String view) {
        try {
            Parent root = FXMLLoader.load(Utils.class.getResource("view/"+view+".fxml"));
            Scene scene = new Scene(root);
            window.setScene(scene);
            window.centerOnScreen();
            window.show();
        } catch (IOException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom otvaranja prozora!" +ex.getMessage());
        }
    }
    
}
