/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustav.model;

/**
 *
 * @author HP
 */
public class Osoba {
    
    private int id;
    private String ime;
    private String prezime;
    private String mjesto_rodenja;
    private String datum_rodenja;
    private String adresa;
    private String spol;
    private String broj_osobne;
    private String oib;
    private String telefon;
    private String zupanija;
    private String grad;
    private byte [] slika;

    public Osoba(int id, String ime, String prezime, String mjesto_rodenja, String datum_rodenja, String adresa, String spol, String broj_osobne, String oib, String telefon, String zupanija, String grad, byte[] slika) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.mjesto_rodenja = mjesto_rodenja;
        this.datum_rodenja = datum_rodenja;
        this.adresa = adresa;
        this.spol = spol;
        this.broj_osobne = broj_osobne;
        this.oib = oib;
        this.telefon = telefon;
        this.zupanija = zupanija;
        this.grad = grad;
        this.slika = slika;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getMjesto_rodenja() {
        return mjesto_rodenja;
    }

    public void setMjesto_rodenja(String mjesto_rodenja) {
        this.mjesto_rodenja = mjesto_rodenja;
    }

    public String getDatum_rodenja() {
        return datum_rodenja;
    }

    public void setDatum_rodenja(String datum_rodenja) {
        this.datum_rodenja = datum_rodenja;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getSpol() {
        return spol;
    }

    public void setSpol(String spol) {
        this.spol = spol;
    }

    public String getBroj_osobne() {
        return broj_osobne;
    }

    public void setBroj_osobne(String broj_osobne) {
        this.broj_osobne = broj_osobne;
    }

    public String getOib() {
        return oib;
    }

    public void setOib(String oib) {
        this.oib = oib;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getZupanija() {
        return zupanija;
    }

    public void setZupanija(String zupanija) {
        this.zupanija = zupanija;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }
    
    

    
    
    
    
    
}
