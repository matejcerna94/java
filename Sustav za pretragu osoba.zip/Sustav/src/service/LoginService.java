/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import sustav.model.Baza;
import sustav.model.Osoba;
import sustav.model.Policajac;

/**
 *
 * @author HP
 */
public class LoginService {
    
    private static PolicajacService policajacService = new PolicajacService();
    static Policajac prijavljeni = null;
    static Osoba prijavljena = null;
    
    public static boolean login (String korisnicko_ime, String lozinka) {
        try {
            PreparedStatement upit = Baza.DB.prepare(
                    "SELECT * FROM policajac WHERE korisnicko_ime=? AND lozinka=?");
            upit.setString(1, korisnicko_ime);
            upit.setString(2, lozinka);
            ResultSet rs = upit.executeQuery();
            if (rs.next()) {
                LoginService.prijavljeni = policajacService.izBazePremaId(rs.getInt(1));
                return true;
                
            } else {
                return false;
            }
        } catch (SQLException ex) {
           
           JOptionPane.showMessageDialog(null, "Greška prilikom prijave!" + ex.getMessage());
           return false;
        }
    }
    
    
    public static Policajac logiraniPolicajac () {
        return LoginService.prijavljeni;
    }
    
    public static Osoba logiranaOsoba () {
        return LoginService.prijavljena;
    }
    
}
