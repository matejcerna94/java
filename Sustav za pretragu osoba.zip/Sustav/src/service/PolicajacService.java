/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import interfaces.model;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import static sustav.model.Baza.DB;
import sustav.model.Policajac;

/**
 *
 * @author HP
 */
public class PolicajacService implements model <Policajac> {
    
    public static final PolicajacService policajacService = new PolicajacService();

    @Override
    public Policajac spasi(Policajac policajac) {
        try {
            PreparedStatement upit = DB.prepare ("INSERT INTO policajac VALUES(null, ?, ?)");
            upit.setString(1, policajac.getKorisnicko_ime());
            upit.setString(2, policajac.getLozinka());
            upit.executeUpdate();
            /* Dohvati id policajca iz baze podataka */
            ResultSet rs = upit.getGeneratedKeys();
            if (rs.next()){
                /* Postavi id policajca iz baze podataka objektu policajac */
                policajac.setId(rs.getInt(1));
            }
            return policajac;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    
    }

    @Override
    public Policajac uredi(Policajac policajac) {
        try {
            PreparedStatement upit = DB.prepare ("UPDATE policajac SET korisnicko_ime=?, lozinka=? WHERE id=?");
            upit.setString(1, policajac.getKorisnicko_ime());            
            upit.setString(2, policajac.getLozinka());
            upit.setInt(3, policajac.getId());
            upit.executeUpdate();
            return policajac;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }    
    }

    @Override
    public boolean brisi(Policajac policajac) {
        try {
            PreparedStatement upit = DB.prepare ("DELETE FROM policajac WHERE id=?");
            upit.setInt(1, policajac.getId());
            upit.executeUpdate();
            return true;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return false;
        }
    
    }

    @Override
    public ObservableList<Policajac> sveIzBaze() {
        try {
            ObservableList <Policajac> policajci = FXCollections.observableArrayList();
        ResultSet rs = DB.select("SELECT * FROM policajac");
            while (rs.next()){
                policajci.add(new Policajac(
                        rs.getInt(1), 
                        rs.getString(2),
                        rs.getString(3)
                ));
            }
            return policajci;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    }

    @Override
    public Policajac izBazePremaId(int id) {
        try {
            PreparedStatement upit = DB.prepare ("SELECT * FROM policajac WHERE id=?");
            upit.setInt(1, id);
            ResultSet rs = upit.executeQuery();
            if (rs.next()){
                return new Policajac(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3)
                );
            } else {
                return null;
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    }

    @Override
    public List<Policajac> traziIzBaze(String pojam) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

     
   
    
    
    
}
