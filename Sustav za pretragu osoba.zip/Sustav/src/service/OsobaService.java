/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import interfaces.model;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import static sustav.model.Baza.DB;
import sustav.model.Osoba;


/**
 *
 * @author HP
 */
public class OsobaService implements model <Osoba>  {
    
    public static final OsobaService osobaService = new OsobaService();

    @Override
    public Osoba spasi(Osoba osoba) {
        try {
            PreparedStatement upit = DB.prepare ("INSERT INTO osoba VALUES(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            upit.setString(1, osoba.getIme());
            upit.setString(2, osoba.getPrezime());
            upit.setString(3, osoba.getMjesto_rodenja());
            upit.setString(4, osoba.getDatum_rodenja());
            upit.setString(5, osoba.getAdresa());
            upit.setString(6, osoba.getSpol());
            upit.setString(7, osoba.getBroj_osobne());
            upit.setString(8, osoba.getOib());
            upit.setString(9, osoba.getTelefon());
            upit.setString(10, osoba.getZupanija());
            upit.setString(11, osoba.getGrad());
            upit.setBytes(12, osoba.getSlika());
            
            
            
            
            
            upit.executeUpdate();
            /* Dohvati id osobe iz baze podataka */
            ResultSet rs = upit.getGeneratedKeys();
            if (rs.next()){
                /* Postavi id osobe iz baze podataka objektu osoba */
                osoba.setId(rs.getInt(1));
            }
            return osoba;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    
    }

    @Override
    public Osoba uredi(Osoba osoba) {
        try {
            PreparedStatement upit = DB.prepare ("UPDATE osoba SET ime=?, prezime=?, mjesto_rodenja=?, datum_rodenja=?, adresa=?, spol=?, broj_osobne=?, oib=?, telefon=?, zupanija=?, grad=?, slika=? WHERE id=?");
            upit.setString(1, osoba.getIme());            
            upit.setString(2, osoba.getPrezime());
            upit.setString(3, osoba.getMjesto_rodenja());
            upit.setString(4, osoba.getDatum_rodenja());
            upit.setString(5, osoba.getAdresa());
            upit.setString(6, osoba.getSpol());
            upit.setString(7, osoba.getBroj_osobne());
            upit.setString(8, osoba.getOib());
            upit.setString(9, osoba.getTelefon());
            upit.setString(10, osoba.getZupanija());
            upit.setString(11, osoba.getGrad());
            upit.setBytes(12, osoba.getSlika());
            upit.setInt(13, osoba.getId());
            upit.executeUpdate();
            return osoba;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }    
    }

    @Override
    public boolean brisi(Osoba osoba) {
        try {
            PreparedStatement upit = DB.prepare ("DELETE FROM osoba WHERE id=?");
            upit.setInt(1, osoba.getId());
            upit.executeUpdate();
            return true;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return false;
        }
    
    }

    @Override
    public ObservableList<Osoba> sveIzBaze() {
        try {
            ObservableList <Osoba> osobe = FXCollections.observableArrayList();
        ResultSet rs = DB.select("SELECT * FROM osoba");
            while (rs.next()){
                osobe.add(new Osoba(
                        rs.getInt(1), 
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getBytes(13)
                        
                ));
            }
            return osobe;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    }

    @Override
    public Osoba izBazePremaId(int id) {
        try {
            PreparedStatement upit = DB.prepare ("SELECT * FROM osoba WHERE id=?");
            upit.setInt(1, id);
            ResultSet rs = upit.executeQuery();
            if (rs.next()){
                return new Osoba(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getBytes(13)
                );
            } else {
                return null;
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    }
    
    @Override
    public ObservableList<Osoba> traziIzBaze(String pojam) {
        try {
            ObservableList <Osoba> osobe = FXCollections.observableArrayList();
        ResultSet rs = DB.select("SELECT * FROM osoba where ime like '%"+ pojam+"%' OR prezime like '%"+pojam+"%' OR mjesto_rodenja like '%"+ pojam+"%' OR datum_rodenja like '%"+ pojam+"%' OR adresa like '%"+ pojam+"%' OR spol like '%"+ pojam+"%' OR broj_osobne like '%"+ pojam+"%' OR oib like '%"+ pojam+"%' OR telefon like '%"+ pojam+"%' OR zupanija like '%"+ pojam+"%' OR grad like '%"+ pojam+"%'");
            while (rs.next()){
                osobe.add(new Osoba(
                        rs.getInt(1), 
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getBytes(13)
                        
                ));
            }
            return osobe;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Greška prilikom izvršavanja upita!" +ex.getMessage());
            return null;
        }
    }
    
    
    
    
}
